﻿# User Agreement

_Yu-Core_(hereinafter referred to as "We") provides to the User (hereinafter referred to as "You") under this Agreement _Swashbuckler Diary_ Service. This Agreement is legally binding on you and on us.

#### 1. Functions of this service

You can use this service to keep a diary.

#### 2. Scope and limitations of liability

The results you get using this service are for reference only. The actual situation is official.

#### 3. Privacy protection

We value the protection of your privacy. Your personal privacy information will be protected and regulated in accordance with the Privacy Policy. Please refer to the Privacy Policy for details.

#### 4, Other Terms

4.1 The title of all the terms of this Agreement is for ease of reading only and has no actual meaning in itself and cannot be used as a basis for the interpretation of the meaning of this Agreement.

4.2 The remaining provisions of this Agreement shall remain valid and binding upon both parties, regardless of the reason for which the provisions of this Agreement are partially invalid or unenforceable.