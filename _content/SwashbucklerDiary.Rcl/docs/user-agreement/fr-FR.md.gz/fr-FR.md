# Accord Utilisateur

_Yu-Core_ (ci-après dénommé "Nous") fournit à l'Utilisateur (ci-après dénommé "Vous") dans le cadre du présent Accord le Service _Swashbuckler Diary_. Cet Accord est légalement contraignant pour vous et pour nous.

#### 1. Fonctions de ce service
Vous pouvez utiliser ce service pour tenir un journal.

#### 2. Étendue et limitations de responsabilité
Les résultats obtenus avec ce service sont fournis à titre indicatif uniquement. La situation réelle fait foi.

#### 3. Protection de la vie privée
Nous attachons une grande importance à la protection de votre vie privée. Vos informations personnelles seront protégées et réglementées conformément à la Politique de Confidentialité. Veuillez vous référer à la Politique de Confidentialité pour plus de détails.

#### 4. Autres Conditions
4.1 Le titre de toutes les clauses du présent Accord est uniquement destiné à faciliter la lecture et n'a aucune signification réelle en soi. Il ne peut être utilisé comme base pour interpréter le sens du présent Accord.

4.2 Les dispositions restantes du présent Accord demeureront valables et contraignantes pour les deux parties, quelle que soit la raison pour laquelle une disposition du présent Accord est partiellement invalide ou inapplicable.