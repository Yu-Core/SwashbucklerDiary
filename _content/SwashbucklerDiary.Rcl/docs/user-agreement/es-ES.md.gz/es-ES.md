# Acuerdo de Usuario

_Yu-Core_ (en adelante "Nosotros") proporciona al Usuario (en adelante "Usted") bajo este Acuerdo el Servicio _Swashbuckler Diary_. Este Acuerdo es legalmente vinculante para usted y para nosotros.

#### 1. Funciones de este servicio
Puede utilizar este servicio para llevar un diario.

#### 2. Alcance y limitaciones de responsabilidad
Los resultados obtenidos mediante este servicio son solo de referencia. La situación real es la oficial.

#### 3. Protección de privacidad
Valoramos la protección de su privacidad. Su información personal será protegida y regulada de acuerdo con la Política de Privacidad. Consulte la Política de Privacidad para más detalles.

#### 4. Otras Condiciones
4.1 El título de todos los términos de este Acuerdo es solo para facilitar la lectura y no tiene significado real por sí mismo, ni puede utilizarse como base para interpretar el significado de este Acuerdo.

4.2 Las disposiciones restantes de este Acuerdo seguirán siendo válidas y vinculantes para ambas partes, independientemente de la razón por la cual alguna disposición de este Acuerdo sea parcialmente inválida o inaplicable.