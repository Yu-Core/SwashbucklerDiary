# Acordo do Usuário

_Yu-Core_ (doravante denominado "Nós") fornece ao Usuário (doravante denominado "Você") sob este Acordo o Serviço _Swashbuckler Diary_. Este Acordo é legalmente vinculativo para você e para nós.

#### 1. Funcionalidades deste serviço
Você pode usar este serviço para manter um diário.

#### 2. Escopo e limitações de responsabilidade
Os resultados obtidos usando este serviço são apenas para referência. A situação real é a oficial.

#### 3. Proteção de privacidade
Valorizamos a proteção de sua privacidade. Suas informações pessoais serão protegidas e regulamentadas de acordo com a Política de Privacidade. Consulte a Política de Privacidade para detalhes.

#### 4. Outros Termos
4.1 O título de todos os termos deste Acordo é apenas para facilitar a leitura e não possui significado real por si só, não podendo ser usado como base para interpretação deste Acordo.

4.2 As disposições restantes deste Acordo permanecerão válidas e vinculantes para ambas as partes, independentemente do motivo pelo qual alguma disposição deste Acordo seja parcialmente inválida ou inexequível.