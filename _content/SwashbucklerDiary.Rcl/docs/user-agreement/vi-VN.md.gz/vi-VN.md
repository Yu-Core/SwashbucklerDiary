# Thỏa thuận Người dùng

_Yu-Core_ (sau đây gọi là "Chúng tôi") cung cấp cho Người dùng (sau đây gọi là "Bạn") Dịch vụ _Swashbuckler Diary_ theo Thỏa thuận này. Thỏa thuận này có hiệu lực ràng buộc pháp lý đối với Bạn và Chúng tôi.

#### 1. Chức năng của dịch vụ
Bạn có thể sử dụng dịch vụ này để ghi nhật ký.

#### 2. Phạm vi và giới hạn trách nhiệm
Kết quả bạn nhận được khi sử dụng dịch vụ này chỉ mang tính chất tham khảo. Tình hình thực tế là chính thức.

#### 3. Bảo vệ quyền riêng tư
Chúng tôi coi trọng việc bảo vệ quyền riêng tư của Bạn. Thông tin cá nhân của Bạn sẽ được bảo vệ và quy định theo Chính sách Bảo mật. Vui lòng tham khảo Chính sách Bảo mật để biết chi tiết.

#### 4. Các Điều khoản Khác
4.1 Tiêu đề của tất cả điều khoản trong Thỏa thuận này chỉ nhằm mục đích dễ đọc, không có ý nghĩa thực tế và không thể được sử dụng làm cơ sở để giải thích nội dung của Thỏa thuận này.

4.2 Các điều khoản còn lại của Thỏa thuận này vẫn có hiệu lực và ràng buộc đối với cả hai bên, bất kể lý do khiến bất kỳ điều khoản nào của Thỏa thuận này bị vô hiệu một phần hoặc không thể thực thi.