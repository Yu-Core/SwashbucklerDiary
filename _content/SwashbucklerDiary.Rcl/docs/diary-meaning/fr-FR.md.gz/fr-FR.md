Pourquoi tenir un journal ?

> Citation de l'utilisateur Zhihu chun-zi-12

Il y a une semaine, je me suis posé une question : "Quel est l'intérêt de publier sur le cercle d'amis ?"

J'ai réfléchi un moment, mais je n'ai pas trouvé de réponse. Alors j'ai tout supprimé.

Le cercle d'amis est-il destiné à être vu par des amis ? Mais quel est l'intérêt de le leur montrer ?

Si le cercle d'amis sert à se souvenir de choses personnelles, pourquoi ne pas simplement écrire un journal ?

Assis à mon bureau, j'ai souvent envie de feuilleter mes anciens journaux.

Parfois, je ris en les lisant, d'autres fois, mes actions passées me semblent incroyables. Je ris, je me fâche ou je reste sans voix.

C'est comme si j'étais un spectateur (un étranger), observant cette enfant, voyant ses actions et comprenant ses sentiments. Je la comprends, je suis d'accord avec elle et je la soutiens. Comme un documentaire ou un film, chaque mouvement, chaque sourire se présente clairement devant moi.

En lisant les journaux des années passées et en les comparant à aujourd'hui, j'ai vraiment envie de dire à mon moi passé : Tu es incroyable ! Tu as tenu bon !

Et à mon moi actuel, je veux dire : Tiens bon encore un peu, peut-être que ton moi futur te remerciera infiniment.

J'aimerais revenir en arrière dans chaque moment d'insécurité, d'anxiété et d'agitation et me dire : Ton moi futur est heureux, tiens bon encore un peu.

Waouh, soudain tout devient clair.

Comme nous voulons nous comprendre nous-mêmes : le journal nous aide à nous voir, à nous reconnaître et à nous améliorer.

Tenir un journal n'a en réalité aucun sens particulier, c'est fait pour lui-même.

[https://www.zhihu.com/question/36073641/answer/216328905](https://www.zhihu.com/question/36073641/answer/216328905)