Tại sao viết nhật ký?

> Trích dẫn từ người dùng Zhihu chun-zi-12

Một tuần trước, tôi đã nghĩ đến một câu hỏi: "Ý nghĩa của việc đăng bài trên vòng kết bạn là gì?"

Tôi suy nghĩ một lúc, nhưng không tìm ra câu trả lời. Vì vậy, tôi đã xóa hết.

Vòng kết bạn là để bạn bè xem? Nhưng ý nghĩa của việc cho bạn bè xem là gì?

Nếu vòng kết bạn là để lưu giữ kỷ niệm cá nhân, tại sao không viết nhật ký?

Khi ngồi trước bàn làm việc, tôi thường có cảm giác muốn lật lại những trang nhật ký cũ.

Đôi khi tôi cười khi đọc chúng, đôi khi tôi thấy những hành động ngày xưa thật khó tin. Tôi cười, tôi giận, hoặc tôi bất lực.

Như một khán giả (người ngoài cuộc), tôi nhìn đứa trẻ đó, xem hành động của cô ấy và hiểu cảm xúc của cô ấy. Tôi hiểu cô ấy, đồng tình và ủng hộ cô ấy. Như một bộ phim tài liệu hay phim ảnh, từng cử chỉ, từng nụ cười đều hiện rõ trước mắt tôi.

Đọc lại nhật ký những năm trước và so sánh với ngày hôm nay, tôi thực sự muốn nói với bản thân ngày xưa: Bạn thật tuyệt vời! Bạn đã kiên trì sống sót!

Và với bản thân hiện tại, tôi muốn nói: Hãy kiên trì thêm chút nữa, biết đâu năm sau bạn sẽ vô cùng biết ơn chính mình ngày hôm nay.

Tôi muốn quay ngược thời gian về những ngày tự ti, lo âu, bất an và nói với chính mình: Ngày mai bạn sẽ hạnh phúc, hãy cố gắng thêm chút nữa.

Ôi, bỗng nhiên mọi thứ trở nên rõ ràng.

Chúng ta khao khát hiểu bản thân đến nhường nào - nhật ký giúp chúng ta nhìn rõ mình, nhận thức và cải thiện bản thân.

Viết nhật ký thực ra không có ý nghĩa gì đặc biệt, nó chỉ đơn giản là vì chính nó.

[https://www.zhihu.com/question/36073641/answer/216328905](https://www.zhihu.com/question/36073641/answer/216328905)