﻿Why keep a diary? 

> From Zhihu user chun-zi-12

A week ago, I thought of a question: "What is the meaning of making WeChat Moment?"

I thought for a while, but there was no answer. Delete them all.

Is the WeChat Moment for friends? What is the meaning of showing it to friends?

If the WeChat Moment is to commemorate themselves, why not keep a diary?

Sitting at the desk, I always have the impulse to read my previous diary.

Sometimes I laugh when I look at it, and sometimes I feel that my behavior at that time is incredible. Will laugh, will be angry, will also want to cry without tears.

Just like a spectator (outsider), go to see the child, see her actions, and understand her mood. Will understand her, will agree with her, will support her. Like a documentary, like a movie, every move, every glance and smile are all presented in front of me.

Look at the diary of the previous years, and look at today. I really want to say to myself in the past: You are great! You insist on living!

I also want to say to myself now: if I persist, I may be grateful to you next year.

I want to go back to every day of my inferiority complex, anxiety and anxiety and tell myself that you are happy tomorrow.

Wow, it's suddenly clear.

How we want to know ourselves is diary, let us see ourselves clearly, know ourselves and improve ourselves.

There is no point in writing a diary, just for the diary itself.

[https://www.zhihu.com/question/36073641/answer/216328905](https://www.zhihu.com/question/36073641/answer/216328905)
