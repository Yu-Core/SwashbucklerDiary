¿Por qué escribir un diario?

> Citado del usuario de Zhihu chun-zi-12

Hace una semana me hice una pregunta: "¿Cuál es el sentido de publicar en el círculo de amigos?"

Reflexioné un rato, pero no encontré respuesta. Así que lo borré todo.

¿El círculo de amigos es para que lo vean los amigos? ¿Pero cuál es el sentido de mostrárselo a los amigos?

Si el círculo de amigos es para recordar cosas propias, ¿por qué no escribir un diario?

Cuando me siento en mi escritorio, a menudo siento el impulso de hojear mis viejos diarios.

A veces me río al leerlos, otras veces me parecen increíbles mis acciones pasadas. Me río, me enfado o me quedo sin palabras.

Es como si fuera un espectador (un extraño), observando a esa niña, viendo sus acciones y entendiendo sus sentimientos. La comprendo, estoy de acuerdo con ella y la apoyo. Como un documental o una película, cada movimiento, cada sonrisa se presenta claramente ante mí.

Al leer los diarios de años anteriores y compararlos con el presente, tengo muchas ganas de decirle a mi yo pasado: ¡Eres increíble! ¡Lograste seguir adelante!

Y a mi yo actual quiero decirle: Aguanta un poco más, tal vez tu yo futuro te lo agradecerá infinitamente.

Me gustaría viajar atrás en el tiempo a cada momento de inseguridad, ansiedad e inquietud y decirme: Tu yo futuro es feliz, aguanta un poco más.

Vaya, de repente todo queda claro.

Cuánto deseamos entendernos a nosotros mismos: el diario nos ayuda a vernos, reconocernos y mejorarnos.

Escribir un diario en realidad no tiene un sentido especial, se hace por sí mismo.

[https://www.zhihu.com/question/36073641/answer/216328905](https://www.zhihu.com/question/36073641/answer/216328905)