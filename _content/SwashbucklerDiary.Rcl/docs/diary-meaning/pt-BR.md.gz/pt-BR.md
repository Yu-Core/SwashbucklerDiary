Por que escrever um diário?

> Citado do usuário do Zhihu chun-zi-12

Uma semana atrás, eu pensei em uma pergunta: "Qual é o sentido de postar no círculo de amigos?"

Pensei por um tempo, mas não encontrei resposta. Então apaguei tudo.

O círculo de amigos é para os amigos verem? Mas qual é o sentido de mostrar para os amigos?

Se o círculo de amigos é para lembrar coisas pessoais, por que não escrever um diário?

Sentado à minha mesa, muitas vezes sinto o impulso de folhear meus diários antigos.

Às vezes eu rio ao lê-los, outras vezes acho minhas ações passadas inacreditáveis. Eu rio, fico bravo ou fico sem palavras.

É como se eu fosse um espectador (um estranho), observando aquela criança, vendo suas ações e entendendo seus sentimentos. Eu a entendo, concordo com ela e a apoio. Como um documentário ou um filme, cada movimento, cada sorriso se apresenta claramente diante de mim.

Ao ler os diários de anos anteriores e compará-los com hoje, eu realmente quero dizer ao meu eu passado: Você é incrível! Você conseguiu seguir em frente!

E ao meu eu atual, quero dizer: Aguenta mais um pouco, talvez seu eu futuro te agradeça infinitamente.

Eu gostaria de voltar no tempo para cada momento de insegurança, ansiedade e inquietação e me dizer: Seu eu futuro é feliz, aguenta mais um pouco.

Uau, de repente tudo ficou claro.

Como queremos nos entender: o diário nos ajuda a nos ver, reconhecer e melhorar.

Escrever um diário na verdade não tem um sentido especial, é feito por si mesmo.

[https://www.zhihu.com/question/36073641/answer/216328905](https://www.zhihu.com/question/36073641/answer/216328905)