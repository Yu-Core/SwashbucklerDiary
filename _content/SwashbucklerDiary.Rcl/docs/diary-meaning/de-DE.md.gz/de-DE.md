Warum Tagebuch schreiben?

> Zitiert von Zhihu-Nutzer chun-zi-12

Vor einer Woche stellte ich mir die Frage: "Was ist der Sinn von Freundeskreis-Posts?"

Ich dachte eine Weile nach, fand aber keine Antwort. Also löschte ich alles.

Ist der Freundeskreis für Freunde gedacht? Aber was ist der Sinn davon, es Freunden zu zeigen?

Wenn der Freundeskreis zur Erinnerung für einen selbst dient, warum dann nicht einfach Tagebuch schreiben?

Wenn ich an meinem Schreibtisch sitze, verspüre ich oft den Drang, meine alten Tagebücher durchzublättern.

Manchmal muss ich lachen, wenn ich sie lese, manchmal finde ich meine damaligen Handlungen unbegreiflich. Ich lache, werde wütend oder bin sprachlos.

Es ist, als wäre ich ein Zuschauer (Außenstehender), der dieses Kind betrachtet, seine Handlungen sieht und seine Gefühle versteht. Ich verstehe es, stimme ihm zu und unterstütze es. Wie eine Dokumentation oder ein Film, jede Bewegung, jedes Lächeln liegt klar vor mir.

Wenn ich die Tagebücher der letzten Jahre lese und sie mit heute vergleiche, möchte ich meinem früheren Ich unbedingt sagen: Du bist großartig! Du hast durchgehalten!

Und meinem heutigen Ich möchte ich sagen: Halte noch etwas durch, vielleicht wird dein zukünftiges Ich dir unendlich dankbar sein.

Ich möchte in jede Zeit meiner Unsicherheit, Angst und Unruhe zurückreisen und mir sagen: Das morgenige Ich ist glücklich, halte noch etwas durch.

Wow, plötzlich wird alles klar.

Wie sehr wir uns doch selbst verstehen wollen – das Tagebuch hilft uns, uns selbst zu sehen, zu erkennen und zu verbessern.

Tagebuch zu schreiben hat eigentlich keinen besonderen Sinn, es geschieht um seiner selbst willen.

[https://www.zhihu.com/question/36073641/answer/216328905](https://www.zhihu.com/question/36073641/answer/216328905)